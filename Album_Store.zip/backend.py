import sqlite3


def connect():
    """Create a new table and add all required columns in the table
    using SELECT statement"""
    conn = sqlite3.connect("books.db")
    conn.execute("CREATE TABLE IF NOT EXISTS songs_table (id INTEGER PRIMARY KEY, track TEXT, artist TEXT, album TEXT, "
                 "year INTEGER)")
    conn.commit()
    conn.close()


def insert(track, artist, album, year):
    """ Insert a new record in the table using INSERT statement
    Args:
        track(text): track name to inserted in table
        artist(text): artist of the track
        album(text): album name
        year(integer): the year in which the album was released
    """
    conn = sqlite3.connect("books.db")
    cur = conn.cursor()
    cur.execute("INSERT INTO songs_table VALUES(NULL,?,?,?,?)", (track, artist, album, year))
    conn.commit()
    conn.close()


def view():
    """ View an existing record in the database using SELECT statement"""
    conn = sqlite3.connect("books.db")
    cur = conn.cursor()
    cur.execute("SELECT * FROM songs_table")
    rows = cur.fetchall()
    conn.close()
    return rows


def search(track="", artist="", album="", year=""):  # you can enter any one entry to get the results.
    """ Search a record in the table using SELECT statement
        Args:
            track(text): track name
            artist(text): artist of the track
            album(text): album name
            year(integer): the year in which the album was released
    """
    conn = sqlite3.connect("books.db")
    cur = conn.cursor()
    cur.execute("SELECT * FROM songs_table WHERE track=? OR artist=? OR album=? OR year=?", (track, artist, album, year))
    rows = cur.fetchall()
    conn.close()
    return rows


def delete(identity):
    """ Delete the selected record from the table using DELETE statement.
        Args:
            identity(integer): It's a unique number assigned to each record in the table
    """
    conn = sqlite3.connect("books.db")
    cur = conn.cursor()
    cur.execute("DELETE FROM songs_table WHERE id=?", (identity,))
    conn.commit()
    conn.close()


def update(identity, track, artist, album, year):  # any one of the fields can be updated.
    """ Update an existing record using UPDATE command.
        Args:
            identity(integer): the identity number of the record to be updated.
            track(text): track name
            artist(text): artist of the track
            album(text): album name
            year(integer): the year in which the album was released
    """
    conn = sqlite3.connect("books.db")
    cur = conn.cursor()
    cur.execute("UPDATE songs_table SET track=?, artist=?, album=?,  year=? WHERE id=?", (track, artist, album, year, identity))
    conn.commit()
    conn.close()


connect()

# insert("Xo tour lif3", "Lil Uzi Vert", "Luv is Rage 2", 2017)



