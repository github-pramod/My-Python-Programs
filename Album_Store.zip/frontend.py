from tkinter import *
import backend


def get_selected_row(event):
    """ To extract the data from the selected tuple and display it on
     individual screens like artist, year, album and track """
    global selected_tuple

    index = listbox.curselection()[0]

    selected_tuple = listbox.get(index)

    entry_track.delete(0, END)
    entry_track.insert(END, selected_tuple[1])

    entry_artist.delete(0, END)
    entry_artist.insert(END, selected_tuple[4])

    entry_album.delete(0, END)
    entry_album.insert(END, selected_tuple[3])

    entry_year.delete(0, END)
    entry_year.insert(END, selected_tuple[2])


def view_command():
    """To view a command display it on GUI"""
    listbox.delete(0, END)
    for row in backend.view():
        listbox.insert(END, row)


def search_command():
    """To search a command and display it on GUI"""
    listbox.delete(0, END)
    for row in backend.search(track_text.get(), artist_text.get(), album_text.get(), year_text.get()):
        listbox.insert(END, row)


def add_command():
    """ To add a record and store it in database"""
    listbox.delete(0, END)
    backend.insert(track_text.get(), artist_text.get(), album_text.get(), year_text.get())
    listbox.insert(END, (track_text.get(), artist_text.get(), album_text.get(), year_text.get()))


def delete_command():
    """ To delete the selected record from the database """
    backend.delete(selected_tuple[0])


def update_command():
    """ To update the selected record in the database"""
    backend.update(selected_tuple[0], track_text.get(), artist_text.get(), album_text.get(), year_text.get())


# ******* GUI for users using Tkinter ***********

root = Tk()

root.title("Music Store")
root.geometry("500x290")

label_track = Label(root, text="Track")
label_track.grid(row=0, column=0)

track_text = StringVar()
entry_track = Entry(root, relief="sunken", bd=2, textvariable=track_text)
entry_track.grid(row=0, column=1)

label_artist = Label(root, text="Artist")
label_artist.grid(row=1, column=0, pady=10)

artist_text = StringVar()
entry_artist = Entry(root, relief="sunken", bd=2, textvariable=artist_text)
entry_artist.grid(row=0, column=3, pady=10)

label_year = Label(root, text="Year")
label_year.grid(row=0, column=2)

year_text = StringVar()
entry_year = Entry(root, relief="sunken", bd=2, textvariable=year_text)
entry_year.grid(row=1, column=1)

label_album = Label(root, text="Album")
label_album.grid(row=1, column=2, pady=10)

album_text = StringVar()
entry_album = Entry(root, relief="sunken", bd=2, textvariable=album_text)
entry_album.grid(row=1, column=3, pady=10)

listbox = Listbox(root)
listbox.grid(row=2, column=0, rowspan=6, columnspan=4, sticky="nsew", padx=5)

sb = Scrollbar(root, orient="vertical", command=listbox.yview)
sb.grid(row=2, column=4, rowspan=6, sticky="nsw")
listbox["yscrollcommand"] = sb.set


listbox.bind('<<ListboxSelect>>', get_selected_row)

view_button = Button(root, text="View all", bd=5, relief="raised", width=12, command=view_command)
view_button.grid(row=2, column=5, padx=10)

search_button = Button(root, text="Search", bd=5, relief="raised", width=12, command=search_command)
search_button.grid(row=3, column=5, padx=10)

add_button = Button(root, text="Add", bd=5, relief="raised", width=12, command=add_command)
add_button.grid(row=4, column=5, padx=10)

update_button = Button(root, bd=5, text="Update", relief="raised", width=12, command=update_command)
update_button.grid(row=5, column=5, padx=10)

delete_button = Button(root, bd=5, text="Delete", relief="raised", width=12, command=delete_command)
delete_button.grid(row=6, column=5, padx=10)

close_button = Button(root, bd=5, text="Close", relief="raised", width=12, command=root.destroy)
close_button.grid(row=7, column=5, padx=10)

root.columnconfigure(1, weight=1)

root.mainloop()
